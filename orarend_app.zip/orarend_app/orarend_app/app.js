import express from 'express'
import path from 'path'
import { fileURLToPath } from 'url'

const app = express()
app.use(express.json())

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

app.use(express.static(path.join(__dirname, 'public')))

let orarend = []

function initializeDatabase() {
    orarend = [
        { nap: "hetfo", ora: 1, tantargy: "Matematika" },
        { nap: "hetfo", ora: 2, tantargy: "Történelem" },
        { nap: "kedd", ora: 1, tantargy: "Fizika" }
    ]
}

initializeDatabase()

app.get('/orarend', (req, res) => {
    res.status(200).json(orarend)
})

app.get("/orarend/:nap/:ora", (req, res) => {
    const { nap, ora } = req.params
    const oraElem = orarend.find(o => o.nap === nap && o.ora === parseInt(ora))
    if (!oraElem) {
        return res.status(404).json({ message: "Óra nem található" })
    }
    res.status(200).json(oraElem)
})

app.post('/orarend', (req, res) => {
    const { nap, ora, tantargy } = req.body
    if (!nap || !ora || !tantargy) {
        return res.status(400).json({ message: "Hiányzó adatok" })
    }
    const ujOra = { nap, ora: parseInt(ora), tantargy }
    orarend.push(ujOra)
    res.status(201).json(ujOra)
})

app.put('/orarend/:nap/:ora', (req, res) => {
    const { nap, ora } = req.params
    const { tantargy } = req.body

    const index = orarend.findIndex(o => o.nap === nap && o.ora === parseInt(ora))
    if (index === -1) {
        return res.status(404).json({ message: "Óra nem található" })
    }

    orarend[index] = { ...orarend[index], tantargy }
    res.status(200).json(orarend[index])
})

app.delete("/orarend/:nap/:ora", (req, res) => {
    const { nap, ora } = req.params
    const index = orarend.findIndex(o => o.nap === nap && o.ora === parseInt(ora))
    if (index === -1) {
        return res.status(404).json({ message: "Óra nem található" })
    }
    orarend.splice(index, 1)
    res.status(200).json({ message: "Óra törölve!" })
})

app.use((err, req, res, next) => {
    console.error(err)
    res.status(500).json({ message: `Szerverhiba: ${err.message}` })
})

const PORT = 3000
app.listen(PORT, () => {
    console.log(`Szerver fut a ${PORT}-es porton`)
})