function fetchHours() {
    fetch('/orarend')
        .then(response => response.json())
        .then(data => {
            const orarendList = document.getElementById('orarend-list');
            orarendList.innerHTML = '';
            data.forEach(ora => {
                const li = document.createElement('li');
                li.innerHTML = `
                    <div><strong>${ora.nap}</strong> - ${ora.ora}. óra: ${ora.tantargy}</div>
                    <div>
                        <button onclick="editHour('${ora.nap}', ${ora.ora})">Szerkesztés</button>
                        <button onclick="deleteHour('${ora.nap}', ${ora.ora})">Törlés</button>
                    </div>
                `;
                orarendList.appendChild(li);
            });
        })
        .catch(error => {
            alert('Hiba történt az adatok lekérésekor');
        });
}

document.getElementById('add-hour-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const nap = document.getElementById('nap').value;
    const ora = document.getElementById('ora').value;
    const tantargy = document.getElementById('tantargy').value;

    fetch('/orarend', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ nap, ora, tantargy })
    })
    .then(response => response.json())
    .then(data => {
        alert('Óra hozzáadva!');
        fetchHours();  
    })
    .catch(error => {
        alert('Hiba történt az óra hozzáadásakor');
    });
    fetchHours();
});

function deleteHour(nap, ora) {
    if (confirm("Biztosan törölni szeretnéd ezt az órát?")) {
        fetch(`/orarend/${nap}/${ora}`, {
            method: 'DELETE',
        })
        .then(response => response.json())
        .then(data => {
            alert('Óra törölve!');
            fetchHours();  
        })
        .catch(error => {
            alert('Hiba történt az óra törlésénél');
        });
    }
}

function editHour(nap, ora) {
    const tantargy = prompt("Milyen tantárgyra szeretnéd cserélni?", "");
    if (tantargy) {
        fetch(`/orarend/${nap}/${ora}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ tantargy })
        })
        .then(response => response.json())
        .then(data => {
            alert('Óra módosítva!');
            fetchHours(); 
        })
        .catch(error => {
            alert('Hiba történt az óra módosításakor');
        });
    }
}


fetchHours();