let users = []

export function dbAll(sql, params = []) {
    return new Promise((resolve, reject) => {
        if (sql.includes("SELECT * FROM users")) {
            resolve(users)
        } else {
            reject(new Error("Ismeretlen lekérdezés"))
        }
    })
}

export function dbGet(sql, params = []) {
    return new Promise((resolve, reject) => {
        if (sql.includes("SELECT * FROM users WHERE name = ?")) {
            const user = users.find(u => u.name === params[0])
            resolve(user || null)
        } else {
            reject(new Error("Ismeretlen lekérdezés"))
        }
    })
}

export function dbRun(sql, params = []) {
    return new Promise((resolve, reject) => {
        try {
            if (sql.startsWith("INSERT INTO users")) {
                const newUser = {
                    id: users.length + 1,
                    name: params[0],
                    age: params[1]
                }
                users.push(newUser)
                resolve({ lastID: newUser.id })
            } else if (sql.startsWith("UPDATE users SET age")) {
                const user = users.find(u => u.name === params[1])
                if (user) {
                    user.age = params[0]
                    resolve({ changes: 1 })
                } else {
                    resolve({ changes: 0 })
                }
            } else if (sql.startsWith("DELETE FROM users WHERE name")) {
                const index = users.findIndex(u => u.name === params[0])
                if (index !== -1) {
                    users.splice(index, 1)
                    resolve({ changes: 1 })
                } else {
                    resolve({ changes: 0 })
                }
            } else {
                resolve({}) 
            }
        } catch (error) {
            reject(error)
        }
    })
}